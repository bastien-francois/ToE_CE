
#from Hofert 2011:  Likelihood inference for Archimedean copulas
LogL <- function(theta, acop, u, n.MC=0, ...) { #
  sum(acop@dacopula(u, theta, n.MC=n.MC, log=TRUE, ...))
}

testCopula3<-function(data_U, family,par_, pobs_to_calc=FALSE){
  name_family_lower=tolower(family)
  if(family=="Clayton"){
    cop_object3 <- claytonCopula(par_, dim=2)
    number_f=3
  }
  if(family=="Gumbel"){
    cop_object3 <- gumbelCopula(par_, dim=2)
    number_f=4
  }
  if(family=="Frank"){
    cop_object3 <- frankCopula(par_, dim=2)
    number_f=5
  }
  if(family=="Joe"){
    cop_object3<- joeCopula(par_, dim=2)
    number_f=6
  }
  if(pobs_to_calc==TRUE){
    data_U<-pobs(as.matrix(cbind(data_U)))
  }
  test_gofWhite=tryCatch({
    BiCopGofTest(data_U[,1],data_U[,2], number_f, par = par_, method = "white",max.df = 30, B = 100, obj = NULL)
  },error=function(e){
  },finally={})
  if(is.null(test_gofWhite)){
    # print("testCopula for VineCopula failed -> package copula 'BFGS'")
    #### sometimes, random bug due to bootstrap, iteration until it works 
    boolError<-TRUE
    k=0
    while(boolError==TRUE && k<=9)
    {
      k=k+1
      tryCatch({
        res <- gofCopula(cop_object3, data_U, N = 100,  estim.method="ml",verbose=FALSE,
                         optim.method="BFGS")#optimize())#"Nelder-Mead")#,optim.method="BFGS")
        boolError<-FALSE
      },error=function(e){
      },finally={})
    }
    ### If no GOF can be computed after several tries,
    if(boolError==TRUE && k>=9){
      # print("testCopula for copula 'BFGS' failed -> package copula 'Nelder-Mead'")
      
      boolError<-TRUE
      k=0
      while(boolError==TRUE && k<=9)
      {
        k=k+1
        tryCatch({
          res <- gofCopula(cop_object3, data_U, N = 100,  estim.method="ml",verbose=FALSE,
                           optim.method="Nelder-Mead")
          boolError<-FALSE
        },error=function(e){
        },finally={})
      }
      ###pval is assumed to be 0
      if(boolError==TRUE && k>=9){
        # print("testCopula for all packages failed -> pval=0")
        res=list("p.value"=0)
      }
    }
  }else{
    res=list("p.value"=test_gofWhite$p.value)
  }
  return(res)
}

#### Three tries (versions) to compute C.I. for theta due to instabilities:
####1.  Package copula, 2. Package VineCopula 3. by hand
determine_ci_theta2<-function(cop_object, data_U, ci_level=0.95){
  # print(paste0("CI ", ci_level, ":"))
  l_mle= cop_object[["logLik"]]
  theta_mle= cop_object[["par"]]
  d=2
  if(cop_object[["family"]]=="Clayton"){
    name_family="Clayton"
    par_lim_inf=-0.9999
    cop_object3 <- claytonCopula(theta_mle, dim=2)
  }
  if(cop_object[["family"]]=="Gumbel"){
    name_family="Gumbel"
    par_lim_inf=1.0001
    cop_object3 <- gumbelCopula(theta_mle, dim=2)
  }
  if(cop_object[["family"]]=="Frank"){
    name_family="Frank"
    par_lim_inf=theta_mle-3
    cop_object3 <- frankCopula(theta_mle, dim=2)
  }
  if(cop_object[["family"]]=="Joe"){
    name_family="Joe"
    par_lim_inf=1.0001
    cop_object3 <- joeCopula(theta_mle, dim=2)
  }
  cop_object2 <- onacopulaL(name_family, list(theta_mle,1:d))
  
  ### Version 1 
  test_efm=tryCatch({
    fit.tau <- fitCopula(cop_object3, data_U, method="ml",
                         optim.method="BFGS")
    ci=confint(fit.tau, level=ci_level)
  }, error=function(e){})
  if(is.null(test_efm)){
    ci=c( "MLE"=theta_mle, c(NaN,NaN))
  }else{
    fit.tau <- fitCopula(cop_object3, data_U, method="ml",
                         optim.method="BFGS")
    ci=confint(fit.tau, level=ci_level)
    ci<-c("MLE"=theta_mle, ci)
  }
  # print(paste0("v1: ", round(ci[1],4), ", [", round(ci[2],4), ", ", round(ci[3],4), "]"))
  
  ### Version 2
  if(sum(is.na(ci))>0){
    test_efm=tryCatch({
      efm <- emle(data_U, cop_object2)
      pfm <- profile(efm)
    }, error=function(e){})
    if(is.null(test_efm)){
      ci=c( "MLE"=theta_mle, c(NaN,NaN))
    }else{
      efm <- emle(data_U, cop_object2)
      pfm <- profile(efm)
      ci  <- confint(pfm, level=ci_level)
      if(length(ci)==0){
        ci<-c("MLE"=theta_mle, NaN, NaN)
      }else{
        ci<-c("MLE"=theta_mle, ci)
      }
    }
  }
  # print(paste0("v2: ", round(ci[1],4), ", [", round(ci[2],4), ", ",  round(ci[3],4), "]"))
  
  ### Version 3: if ci still has NaNs
  if(sum(is.na(ci))>0){
    if(is.na(ci[2])){
      # print("ci_low a la main")
      th4=seq(theta_mle,par_lim_inf-0.0001,by=-0.0001) ### from theta mle to lower bound
      Chi=qchisq(ci_level, df=1)
      Lt1=LogL(theta_mle, cop_object2@copula, data_U)
      LR=2*(l_mle-Lt1)
      k=1
      while(LR<=Chi & th4[k]>=par_lim_inf){
        k=k+1
        Lt1 <- LogL(th4[k], cop_object2@copula, data_U)
        LR=2*(l_mle-Lt1)
      }
      if(k==length(th4)){
        ci[2]=par_lim_inf
      }else{
        ci[2]=th4[k]
      }
      # print(paste0("CI comp: ", ci[2]))
    }
    if(is.na(ci[3])){
      # print("ci_high a la main")
      th4=seq(theta_mle,theta_mle+3,by=0.0001)
      Chi=qchisq(ci_level, df=1)
      Lt1=LogL(theta_mle, cop_object2@copula, data_U)
      LR=2*(l_mle-Lt1)
      k=1
      while(LR<=Chi){
        k=k+1
        Lt1 <- LogL(th4[k], cop_object2@copula, data_U)
        LR=2*(l_mle-Lt1)
      }
      ci[3]=th4[k]
      # print(paste0("CI comp: ", ci[3]))
    }
  }
  # print(paste0("v3: ", round(ci[1],4), ", [", round(ci[2],4), ", ", round(ci[3],4), "]"))
  ### to avoid cases where ci goes beyond lim inf
  if(ci[2]<par_lim_inf & name_family %in% c("Frank", "Joe", "Gumbel", "Clayton")){ci[2]<-par_lim_inf}
  # print(paste0("vf: ", round(ci[1],4), ", [", round(ci[2],4), ", ",  round(ci[3],4), "]"))
  return(ci)
}

determine_ci_prob_bivar_array2<-function(cop_object, ci_theta, prob_vector1=NaN,
                                         prob_vector2=NaN, zone_bivar=NaN){ #output format:prob_vector2 x prob_vector1 x CI
  name_family=cop_object$family
  d=2
  expand_proba=expand.grid(x=prob_vector1, y=prob_vector2) #x and y in column, x with y fixed
  
  ### res_prob of format: probs_to_eval_1 x probs_to_eval_2 x (MLE, 0.025, 0.975)
  res_prob=array(NaN, dim=c(length(prob_vector1), length(prob_vector2), 3))
  ### ATTENTION, when plot with image.plot: probs_to_eval_1 x probs_to_eval_2 x (MLE, 0.025, 0.975)
  length_ci_theta=3
  ### loop over the different values of theta: MLE and ci_low and ci_high
  for(coord_theta in 1:length_ci_theta){
    test_fit_Cop_lowci=tryCatch({
      BiCop(cop_object$family, ci_theta[coord_theta])
    }, error=function(e){})
    if(is.null(test_fit_Cop_lowci)){
      fitted_cop_lowci <- onacopulaL(name_family, list(ci_theta[coord_theta],1:d))
      ## Evaluate this copula at prob_bivar
      if(zone_bivar=="topright"){
        tmp_mat=matrix(apply(expand_proba,1,function(x){(1-pCopula(c(1, x[2]), fitted_cop_lowci)
                                                         -pCopula(c(x[1], 1), fitted_cop_lowci)
                                                         +pCopula(c(x[1], x[2]), fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
      }
      if(zone_bivar=="topleft"){
        tmp_mat=matrix(apply(expand_proba,1,function(x){( pCopula(c(x[1], 1), fitted_cop_lowci) 
                                                          -pCopula(c(x[1], x[2]), fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
      }
      res_prob[,,coord_theta]<-tmp_mat 
    }else{
      fitted_cop_lowci<-test_fit_Cop_lowci
      ## Evaluate this copula at prob_bivar
      if(zone_bivar=="topright"){
        tmp_mat=matrix(apply(expand_proba,1,function(x){(1-BiCopCDF(1, x[2], fitted_cop_lowci)
                                                         -BiCopCDF(x[1], 1, fitted_cop_lowci)
                                                         + BiCopCDF(x[1], x[2], fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
      }
      if(zone_bivar=="topleft"){
        tmp_mat=matrix(apply(expand_proba,1,function(x){(BiCopCDF(x[1], 1, fitted_cop_lowci)
                                                         - BiCopCDF(x[1], x[2], fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
      }
      res_prob[,,coord_theta]<-tmp_mat 
    }
  }
  #### We inverse low_ci and high_ci when zone_bivar="topleft"
  if(zone_bivar=="topleft"){
    tmp_save_low=res_prob[,, 2] 
    tmp_save_high=res_prob[,, 3] 
    res_prob[,,2]<-tmp_save_high 
    res_prob[,,3]<-tmp_save_low 
  }
  ### Check for very small values:
  epsilon=.Machine$double.eps
  res_prob[res_prob<=epsilon]<-0
  return(res_prob)
}



determine_bootstrap_prob_bivar<-function(cop_object, theta, prob_vector1=NaN,
                                         prob_vector2=NaN, zone_bivar=NaN){ #prob_matrix format:prob_vector2 x prob_vector1 x CI
  name_family=cop_object$family
  d=2
  expand_proba=expand.grid(x=prob_vector1, y=prob_vector2) #x and y en colonne, x qui defile avec y fixe
  
  ### res_prob of format probs_to_eval_1 x probs_to_eval_2 
  res_prob=matrix(NaN, nrow=length(prob_vector1), ncol=length(prob_vector2))
  test_fit_Cop_lowci=tryCatch({
    BiCop(cop_object$family, theta)
  }, error=function(e){})
  if(is.null(test_fit_Cop_lowci)){
    fitted_cop_lowci <- onacopulaL(name_family, list(theta,1:d))
    ## Evaluate this copula at prob_bivar
    if(zone_bivar=="topright"){
      tmp_mat=matrix(apply(expand_proba,1,function(x){(1-pCopula(c(1, x[2]), fitted_cop_lowci)
                                                       -pCopula(c(x[1], 1), fitted_cop_lowci)
                                                       +pCopula(c(x[1], x[2]), fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
    }
    if(zone_bivar=="topleft"){
      tmp_mat=matrix(apply(expand_proba,1,function(x){( pCopula(c(x[1], 1), fitted_cop_lowci) 
                                                        -pCopula(c(x[1], x[2]), fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
    }
    res_prob<-tmp_mat 
  }else{
    fitted_cop_lowci<-test_fit_Cop_lowci
    ## Evaluate this copula at prob_bivar
    if(zone_bivar=="topright"){
      tmp_mat=matrix(apply(expand_proba,1,function(x){(1-BiCopCDF(1, x[2], fitted_cop_lowci)
                                                       -BiCopCDF(x[1], 1, fitted_cop_lowci)
                                                       + BiCopCDF(x[1], x[2], fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
    }
    if(zone_bivar=="topleft"){
      tmp_mat=matrix(apply(expand_proba,1,function(x){(BiCopCDF(x[1], 1, fitted_cop_lowci)
                                                       - BiCopCDF(x[1], x[2], fitted_cop_lowci))}),byrow=TRUE,ncol=length(prob_vector1))
    }
    res_prob<-tmp_mat 
  }
  ### For very small values:
  epsilon=.Machine$double.eps
  res_prob[res_prob<=epsilon]<-0
  return(res_prob)
}



selectedCopula3<-function(data_U, pobs_to_calc=FALSE){
  AIC=list()
  par=list()
  logLik=list()
  family=c("Clayton", "Gumbel", "Frank", "Joe")
  for(f in family){
    tmp_res=determine_theta3(data_U, f, pobs_to_calc=FALSE)
    AIC[[f]]=2-2*tmp_res$logLik
    par[[f]]=tmp_res$par
    logLik[[f]]=tmp_res$logLik
  }
  res=list()
  res[["family"]]=names(which.min(AIC))
  res[["par"]]=as.numeric(par[[names(which.min(AIC))]])
  res[["logLik"]]=as.numeric(logLik[names(which.min(AIC))])
  return(res)
}

determine_theta3<-function(data_U, family, pobs_to_calc=FALSE){
  if(pobs_to_calc==TRUE){
    data_U<-pobs(as.matrix(cbind(data_U)))
  }
  res=list()
  res[["family"]]=family
  if(family=="Clayton"){
    cop_object3 <- claytonCopula(dim=2)
    number_f=3
    par_lim_inf=-0.9999
  }
  if(family=="Gumbel"){
    cop_object3 <- gumbelCopula(dim=2)
    number_f=4
    par_lim_inf=1.0001
  }
  if(family=="Frank"){
    cop_object3 <- frankCopula(dim=2)
    number_f=5
    par_lim_inf=-Inf
  }
  if(family=="Joe"){
    cop_object3 <- joeCopula(dim=2)
    number_f=6
    par_lim_inf=1.0001
  }
  
  test_fit_BFGS=tryCatch({
    fit=fitCopula(cop_object3, data_U, method="ml", optim.method="BFGS") 
  }, error=function(e){})
  
  if(is.null(test_fit_BFGS)){
    test_fit_NelderMead=tryCatch({
      fit=fitCopula(cop_object3, data_U, method="ml", optim.method="Nelder-Mead") 
    }, error=function(e){})
    if(is.null(test_fit_NelderMead)){
      # print("determine_theta done with VineCopula")
      est_BiCop=BiCopEst(data_U[,1],data_U[,2],number_f,method = "mle")
      res[["logLik"]]= est_BiCop$logLik
      res[["par"]]= est_BiCop$par
    }else{
      # print("determine_theta done with Nelder-Mead")
      fit=test_fit_NelderMead
      res[["par"]]= fit@estimate
      res[["logLik"]]= fit@loglik
    }
  }else{
    # print("determine_theta done with BFGS")
    fit=test_fit_BFGS
    res[["par"]]= fit@estimate
    res[["logLik"]]= fit@loglik
  }
  if(res[["par"]]<=par_lim_inf){res[["par"]]<-par_lim_inf}
  return(res)
}

#### FIT GPD over thresh and its inverse
F_GPD<-function(data_x, thresh_GPD, points_to_estimate){
  ### Fit F_hat with data_x
  # can have pb as: "observed information matrix is singular; use std.err = FALSE"
  test_fit=tryCatch({
    (fitted<- evd::fpot(data_x, thresh_GPD))
  }, error=function(e){})
  if(is.null(test_fit)){
    (fitted <- evd::fpot(data_x, thresh_GPD, std.err=FALSE))
  }else{
    fitted=test_fit
  }
  # print(paste0("loc: ", thresh_GPD, ", scale: ", fitted$estimate[1], ", shape:", fitted$estimate[2]))
  ### Estimate F_hat(points_to_estimate)
  p_of_x=evd::pgpd(points_to_estimate,loc =thresh_GPD,
                   scale=fitted$estimate[1], shape=fitted$estimate[2])
  return(p_of_x)
}

Fm1_GPD<-function(data_x, thresh_GPD, probs_to_estimate){
  ### Fit F_hat with data_x
  test_fit=tryCatch({
    (fitted<- evd::fpot(data_x, thresh_GPD))
  }, error=function(e){})
  if(is.null(test_fit)){
    (fitted <- evd::fpot(data_x, thresh_GPD, std.err=FALSE))
  }else{
    fitted=test_fit
  }
  ### Estimate Fm1_hat
  q_of_x=evd::qgpd(probs_to_estimate, loc =thresh_GPD,
                   scale=fitted$estimate[1], shape=fitted$estimate[2])
  return(q_of_x)
}


reord_in_list_winter<-function(index, label_sw, nb_index_by_year,
                               length_sw){
  res_list=list()
  k=0
  for(l in 1:length(label_sw)){
    if(l==1){### 29 years of index and JanFeb for the first window
      start_=1
      end_=nb_index_by_year*(length_sw-1)+59
      res_list[[label_sw[l]]]=index[start_:end_]
    }
    if(l==length(label_sw)){ #29 years of index + Dec. 2100
      start_=length(index)-(nb_index_by_year*(length_sw-1))-31+1
      end_= length(index)
      res_list[[label_sw[l]]]=index[start_:end_]
    }
    if(l!=1 && l!= length(label_sw)){ ## 30 years of index
      start_=(k*nb_index_by_year+1-31)
      end_=start_+nb_index_by_year*length_sw-1
      res_list[[label_sw[l]]]=index[start_:end_]
    }
    k=k+1
  } 
  return(res_list)
}

compute_daily_spat_sum<-function(daily_data,Ind_season){
  nb_lat=dim(daily_data)[1]
  nb_lon=dim(daily_data)[2]
  tmp_daily_data <- t(matrix(daily_data, nrow = nrow(daily_data)
                             * ncol(daily_data)))
  spavg_daily_data <- apply(tmp_daily_data, 1, sum, na.rm=T) #Spatial average for the season
  
  return(spavg_daily_data)
}
compute_daily_spat_mean<-function(daily_data,Ind_season){
  nb_lat=dim(daily_data)[1]
  nb_lon=dim(daily_data)[2]
  tmp_daily_data <- t(matrix(daily_data, nrow = nrow(daily_data)
                             * ncol(daily_data)))
  spavg_daily_data <- apply(tmp_daily_data, 1, mean, na.rm=T) #Spatial average for the season
  
  return(spavg_daily_data)
}

compute_ToE<-function(proba, low_bound, high_bound, length_SlidingWindow,
                      period_){
  substrRight <- function(x, n){
    substr(x, nchar(x)-n+1, nchar(x))
  }
  period_max=as.numeric(substrRight(period_, 4)) ### is equal to 2100
  k=length(proba) 
  ## particular case for very small values....
  if(low_bound>=high_bound && low_bound<=10*.Machine$double.eps){
    low_bound=high_bound=0
  }
  if(proba[k]>=low_bound && proba[k]<=high_bound){
    ### no ToE
    TOE=NaN
    TOE_text="NaN"
    length_last_seq=NaN
    coord_TOE=NaN
  }else{
    while(proba[k]<low_bound | proba[k]>high_bound){
      k=k-1
    }
    length_last_seq=length(proba)-(k)
    coord_TOE=length(proba)-length_last_seq+1
    TOE=period_max-(length_SlidingWindow/2)+1-length_last_seq+1
    TOE_text=paste0(period_max-length_last_seq+1-length_SlidingWindow+1,
                    "-", period_max-length_last_seq+1)
  }
  return(list(TOE=TOE, TOE_text=TOE_text, length_last_seq=length_last_seq, coord_TOE=coord_TOE))
}



compute_ToE_matrix_from_array<-function(array_res_proba, length_SlidingWindow,
                                        period_, coord_baseline){
  nb_index1=dim(array_res_proba)[2]
  nb_index2=dim(array_res_proba)[1]
  mat_TOE=matrix(NaN, ncol=nb_index1, nrow=nb_index2)
  mat_coord_TOE=matrix(NaN, ncol=nb_index1, nrow=nb_index2)
  mat_TOE_text=matrix(NaN, ncol=nb_index1, nrow=nb_index2)
  for(p_of_index2 in 1:nb_index2){
    for(p_of_index1 in 1:nb_index1){
      tmp_proba=array_res_proba[p_of_index2,p_of_index1,,1]
      tmp_low_bound=min(array_res_proba[p_of_index2,p_of_index1,coord_baseline,2])
      tmp_high_bound=max(array_res_proba[p_of_index2,p_of_index1,coord_baseline,3])
      tmp_TOE=compute_ToE(tmp_proba, tmp_low_bound, tmp_high_bound, length_SlidingWindow,
                          period_)
      TOE=tmp_TOE$TOE
      TOE_coord_TOE=tmp_TOE$coord_TOE
      TOE_text=tmp_TOE$TOE_text
      #### Fill the matrices
      mat_TOE[p_of_index2, p_of_index1]=TOE
      mat_coord_TOE[p_of_index2, p_of_index1]=TOE_coord_TOE
      mat_TOE_text[p_of_index2, p_of_index1]=TOE_text
    }
  }
  return(list(TOE=mat_TOE, coord_TOE=mat_coord_TOE, TOE_text=mat_TOE_text))
}


## To compute_Contrib
compute_Contrib_matrix_from_array<-function(array_margdep,array_marg, array_dep, coord_Ref){
  tmp_margdep=array_margdep[,,,1]
  tmp_marg=array_marg[,,,1]
  tmp_dep=array_dep[,,,1]
  p00<-replicate(dim(array_margdep)[3], array_margdep[,,coord_Ref,1], simplify="array")
  effet_total=tmp_margdep-p00
  effet_marg=tmp_marg- p00
  effet_dep=tmp_dep- p00
  effet_int= effet_total-effet_dep-effet_marg
  FAR_margdep= effet_total/tmp_margdep
  FAR_marg= effet_marg/tmp_margdep
  FAR_dep= effet_dep/tmp_margdep
  FAR_int= effet_int/tmp_margdep
  Ecart_relat_margdep= effet_total/p00
  Ecart_relat_margdep[is.infinite(Ecart_relat_margdep)]<-NaN
  Ecart_relat_marg= effet_marg/p00
  Ecart_relat_dep= effet_dep/p00
  Ecart_relat_int= effet_int/p00
  Contrib_marg=effet_marg/effet_total*100
  Contrib_dep=effet_dep/effet_total*100
  Contrib_int=effet_int/effet_total*100
  return(list(Contrib_marg=Contrib_marg, 
              Contrib_dep=Contrib_dep, 
              Contrib_int=Contrib_int,
              Ecart_relat_margdep=Ecart_relat_margdep,
              Ecart_relat_marg= Ecart_relat_marg,
              Ecart_relat_dep=Ecart_relat_dep,
              Ecart_relat_int=Ecart_relat_int,
              FAR_margdep=FAR_margdep,
              FAR_marg=FAR_marg,
              FAR_dep=FAR_dep,
              FAR_int=FAR_int))
}

## To plot Contrib time series, matrix and barplot
fastplot_Contrib<-function(input,p_i2,p_i1, plot_ts=NaN, plot_matrix=NaN,
                           plot_barplot=NaN,coord_sub_ts=NaN,
                           subplot_name=c("(d)", "(e)", "(f)")){
  Med_C_marg<-apply(input$Contrib_marg,c(1,2), function(x){median(x[coord_sub_ts],na.rm=TRUE)})
  Med_C_dep<-apply(input$Contrib_dep,c(1,2), function(x){median(x[coord_sub_ts],na.rm=TRUE)})
  Med_C_int<-apply(input$Contrib_int,c(1,2), function(x){median(x[coord_sub_ts],na.rm=TRUE)})
  tmp_Contrib_marg=input$Contrib_marg[p_i2, p_i1,coord_sub_ts]
  tmp_Contrib_dep=input$Contrib_dep[p_i2, p_i1,coord_sub_ts]
  tmp_Contrib_int=input$Contrib_int[p_i2, p_i1,coord_sub_ts]
  coord_Contrib_marg_high<- which(tmp_Contrib_marg>150)
  coord_Contrib_marg_low<- which(tmp_Contrib_marg<(-150))
  coord_Contrib_dep_high<- which(tmp_Contrib_dep>150)
  coord_Contrib_dep_low<- which(tmp_Contrib_dep<(-150))
  coord_Contrib_int_high<- which(tmp_Contrib_int>150)
  coord_Contrib_int_low<- which(tmp_Contrib_int<(-150))
  tmp_Contrib_marg[(tmp_Contrib_marg>150 | tmp_Contrib_marg<(-150))]<-NaN
  tmp_Contrib_dep[(tmp_Contrib_dep>150 | tmp_Contrib_dep<(-150))]<-NaN
  tmp_Contrib_int[(tmp_Contrib_int>150 | tmp_Contrib_int<(-150))]<-NaN
  if(plot_ts==TRUE){
    plot(input$FAR_margdep[p_i2, p_i1,coord_sub_ts], xaxt="n", ylab="Bivar. FAR", xlab="Sliding windows",type='l',
         ylim=c(-1,1), cex.axis=1.7, cex.lab=1.7)
    abline(h=0)
    axis(1,xlab_pos,xlab_name, cex.axis=1.7)
    lines(input$FAR_marg[p_i2, p_i1,coord_sub_ts], type="l",
          col=col_main[1])
    lines(input$FAR_dep[p_i2, p_i1,coord_sub_ts], type="l",
          col=col_main[2])
    lines(input$FAR_int[p_i2, p_i1,coord_sub_ts], type="l",
          col=col_main[3])
    legend("bottomright", c(expression(paste(Delta, "P"^"FAR", sep="")),
                            expression(paste(Delta, "M"^"FAR", sep="")),
                            expression(paste(Delta,"D"^"FAR", sep="")), 
                            expression(paste(Delta, "I"^"FAR", sep=""))),
           lty=c(1,1,1), col=c("black", col_main[1],
                               col_main[2], col_main[3]), cex=1.5, bg="white")
    legend("topright", c("(d)"), cex=2.5, bty="n")
    if(sum(is.nan(input$Ecart_relat_margdep[p_i2, p_i1,coord_sub_ts]))==length(input$Ecart_relat_margdep[p_i2, p_i1,coord_sub_ts])){
      plot.new()
    }else{
      plot(input$Ecart_relat_margdep[p_i2, p_i1,coord_sub_ts], xaxt="n", 
           ylab="Relat. diff.", xlab="Sliding windows",type='l', ylim=c(-0.5,
                                                                        2),
           cex.axis=1.7,
           cex.lab=1.7)
      abline(h=0)
      axis(1,xlab_pos,xlab_name, cex.axis=1.7)
      lines(input$Ecart_relat_marg[p_i2, p_i1,coord_sub_ts], type="l", col=col_main[1])
      lines(input$Ecart_relat_dep[p_i2, p_i1,coord_sub_ts], type="l", col=col_main[2])
      lines(input$Ecart_relat_int[p_i2, p_i1,coord_sub_ts], type="l", col=col_main[3])
      legend("topleft",  c(expression(paste(Delta, "P"^"r. diff", sep="")),
                           expression(paste(Delta, "M"^"r. diff", sep="")),
                           expression(paste(Delta,"D"^"r. diff", sep="")), 
                           expression(paste(Delta, "I"^"r. diff", sep=""))),
             lty=c(1,1,1), col=c("black", col_main[1], col_main[2],
                                 col_main[3]), cex=1.5, bg="white")
      legend("topright", c("(e)"), cex=2.5, bty="n")
    }
    plot(tmp_Contrib_marg,ylim=c(-150,150), col=col_main[1], type="l",
         ylab="Contribution (%)", xlab="Sliding windows", xaxt="n",
         cex.axis=1.7, cex.lab=1.7)
    axis(1,xlab_pos,xlab_name, cex.axis=1.7)
    lines(tmp_Contrib_dep,ylim=c(-100,100), col=col_main[2], type='l')
    lines(tmp_Contrib_int,ylim=c(-100,100), col=col_main[3], type='l')
    abline(h=0,lty=2)
    abline(h=-100,lty=2)
    abline(h=100,lty=2)
    abline(h=Med_C_marg[p_i2, p_i1], col=col_main[1], lwd=2, lty=2)
    abline(h=Med_C_dep[p_i2, p_i1],  col=col_main[2], lwd=2, lty=2)
    abline(h=Med_C_int[p_i2, p_i1], col=col_main[3], lwd=2, lty=2)
    
    points(coord_Contrib_marg_high,rep(150,length(coord_Contrib_marg_high)),pch=8,
           col=col_main[1])
    points(coord_Contrib_marg_low,rep(-150,length(coord_Contrib_marg_low)),pch=8,
           col=col_main[1])
    points(coord_Contrib_dep_high,rep(150,length(coord_Contrib_dep_high)),pch=8,
           col=col_main[2])
    points(coord_Contrib_dep_low,rep(-150,length(coord_Contrib_dep_low)),pch=8,
           col=col_main[2])
    points(coord_Contrib_int_high,rep(150,length(coord_Contrib_int_high)),pch=8,
           col=col_main[3])
    points(coord_Contrib_int_low,rep(-150,length(coord_Contrib_int_low)),pch=8,
           col=col_main[3])
    legend("bottomright", c(expression(paste("Contrib"[Delta]["M"], sep="")),
                            expression(paste("Contrib"[Delta]["D"], sep="")),
                            expression(paste("Contrib"[Delta]["I"], sep=""))),
           lty=c(1,1,1), col=c( col_main[1],
                                col_main[2], col_main[3]), cex=1.5, bg="white")
    legend("topright", c("(f)"), cex=2.5, bty="n")
  }
  if(plot_matrix==TRUE){
    image.plot(1:19,1:19,postproc_image.plot(Med_C_marg),xaxt="n",
               yaxt="n",zlim=c(-30, 130),col=brbgPal, xlab=x_axis_lab,
               ylab=y_axis_lab,
               main=expression(~bold(paste("Median Contrib"[Delta]["M"],
                                           sep=""))),
               cex.main=2, cex.lab=1.7, cex.axis=1.7,
               axis.args=list(cex.axis=1.5))
    points(which(postproc_image.plot(Med_C_marg)>=postproc_image.plot(Med_C_dep),arr.ind=TRUE), pch=2)
    points(which(postproc_image.plot(Med_C_marg)<=(-30),arr.ind=TRUE), pch=20,
           col=brbgPal[1])
    axis(1,seq(2,18,by=4),round(quant_Init_index1_CNRMCM6[seq(2,18,by=4)],1),
         cex.axis=1.7)
    axis(2,seq(2,18,by=4),round(quant_Init_index2_CNRMCM6[seq(2,18,by=4)],1),
         cex.axis=1.7)
    legend("topleft", c("(d)"), cex=2.5, bty="n")
    image.plot(1:19,1:19,postproc_image.plot(Med_C_dep),xaxt="n",
               yaxt="n",zlim=c(-30, 130),col=brbgPal, xlab=x_axis_lab,
               ylab=y_axis_lab,
               main=expression(~bold(paste("Median Contrib"[Delta]["D"],
                                           sep=""))),
               cex.main=2, cex.lab=1.7, cex.axis=1.7,
               axis.args=list(cex.axis=1.5))
    points(which(postproc_image.plot(Med_C_dep)>=postproc_image.plot(Med_C_marg),arr.ind=TRUE), pch=2)
    points(which(postproc_image.plot(Med_C_dep)<=(-30),arr.ind=TRUE), pch=20,
           col=brbgPal[1])
    axis(1,seq(2,18,by=4),round(quant_Init_index1_CNRMCM6[seq(2,18,by=4)],1),
         cex.axis=1.7)
    axis(2,seq(2,18,by=4),round(quant_Init_index2_CNRMCM6[seq(2,18,by=4)],1),cex.axis=1.7)
    legend("topleft", c("(e)"), cex=2.5, bty="n")
    image.plot(1:19,1:19,postproc_image.plot(Med_C_int),xaxt="n",
               yaxt="n",zlim=c(-30, 130),col=brbgPal, xlab=x_axis_lab,
               ylab=y_axis_lab,
               main=expression(~bold(paste("Median Contrib"[Delta]["I"],
                                           sep=""))),
               cex.main=2, cex.lab=1.7, cex.axis=1.7,
               axis.args=list(cex.axis=1.5))
    axis(1,seq(2,18,by=4),round(quant_Init_index1_CNRMCM6[seq(2,18,by=4)],1),
         cex.axis=1.7)
    axis(2,seq(2,18,by=4),round(quant_Init_index2_CNRMCM6[seq(2,18,by=4)],1),
         cex.axis=1.7)
    legend("topleft", c("(f)"), cex=2.5, bty="n")
  }
  if(plot_barplot==TRUE){
    mat_count=matrix(NaN,ncol=1, nrow=3)
    rownames(mat_count)<-c("Marg.", "Dep.", "Int.")
    colnames(mat_count)<-c("Model CNRMCM6")#paste0(Model ", Mod))
    mat_count[,1]=c(Med_C_marg[p_i2,p_i1], Med_C_dep[p_i2,p_i1],
                    Med_C_int[p_i2,p_i1])
    barplot(mat_count, col=c(col_main[1], col_main[2], col_main[3]), beside=TRUE,
            ylab="Median contribution (%)", ylim=c(-150,150), las=1)
    legend("topright",
           legend = c("Marg.", "Dep.", "Int."),
           fill = c(col_main[1], col_main[2], col_main[3]))
    abline(h=0)
    abline(h=100,lty=2)
    abline(h=-150, lty=2)
  }
}
