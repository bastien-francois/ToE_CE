########## Demo for Time of Emergence article with data from CNRM-CM6 #########

rm(list=ls())
# install.packages("copula")
library(copula)
setwd("/home/francois/Documents/LSCE/TCE6/Demo/")
source("function_Demo_ToE.R")
load("Compound_Event_Temporal_indices_SlidingWindows_1850_2100.RData")
load("pr_day_CNRMCM6_1850_2100_Bretagne.RData")
load("sfcWindmax_day_CNRMCM6_1850_2100_Bretagne.RData")

Length_SlidingWindow=30

period="1850_2100"
nb_years_=251
Label_SlidingWindowX= Label_SlidingWindow30_1850_2100

## Sliding window of 30 years as reference
Ref_SlidingWindow="1871_1900"
coord_Ref_SlidingWindow=which(Label_SlidingWindowX==Ref_SlidingWindow)
nb_listX=length(Label_SlidingWindowX)
zone_="topright"

### Select winter over the period of interest
var1=pr_day_CNRMCM6_1850_2100_Bretagne[,,Ind_winter_1850_2100]
var2=sfcWindmax_day_CNRMCM6_1850_2100_Bretagne[,,Ind_winter_1850_2100]

### Indices: Daily mean of Windmax and daily sum of pr over the region
index1=compute_daily_spat_mean(var1)
index2=compute_daily_spat_sum(var2)

nb_index_by_year_=length(Ind_winter_1850_2100)/nb_years_

tmp_listX_index1<-reord_in_list_winter(index1, Label_SlidingWindowX,
                                       nb_index_by_year_, length_sw = Length_SlidingWindow)
tmp_listX_index2<-reord_in_list_winter(index2, Label_SlidingWindowX,
                                       nb_index_by_year_, length_sw = Length_SlidingWindow)
uncond_listX_index1<- tmp_listX_index1
uncond_listX_index2<- tmp_listX_index2

### Compute quantile 90 for each index
quant90_index1=quantile(tmp_listX_index1[[coord_Ref_SlidingWindow]],probs=0.9, na.rm=T)
quant90_index2=quantile(tmp_listX_index2[[coord_Ref_SlidingWindow]],probs=0.9, na.rm=T)

### Subsetting over quant90
listX_index1=list()
listX_index2=list()

for(l in Label_SlidingWindowX){
  coord_phy=which(tmp_listX_index1[[l]]>=quant90_index1
                  & tmp_listX_index2[[l]]>=quant90_index2)
  listX_index1[[l]]=tmp_listX_index1[[l]][coord_phy]
  listX_index2[[l]]=tmp_listX_index2[[l]][coord_phy]
}



#### Computations of proba
### Probs to evaluate
probs_to_eval=seq(0.8,0.9, 0.1)#In the original paper, probs_to_eval=seq(0.05, 0.95,0.05)
probs_to_eval_index1= probs_to_eval_index2=probs_to_eval

probs_listX_index1=matrix(NaN, ncol=length(probs_to_eval_index1), nrow=
                            length(Label_SlidingWindowX)) #format SlidingWindow x probs
probs_listX_index2=matrix(NaN, ncol=length(probs_to_eval_index2), nrow=
                            length(Label_SlidingWindowX)) ###format SlidingWindow x probs
res_name_best_Copula=rep(NaN, nb_listX)

family_to_try= 'Gumbel'# For CNRM-CM6, the best is Gumbel over all the sliding window (not shown) 
#One can put family_to_try=c("Frank", "Joe", "Clayton", "Gumbel") to define the best family.
# Please refer to appendix B for the methodology to define the best family.
for(f in c(family_to_try)){
  assign(paste0("res_Goftest_",f),rep(NaN, nb_listX))
  assign(paste0("res_theta_",f, "_68"),list())
  assign(paste0("array_prob_margdep_68_",f), array(NaN,dim=c(length(probs_to_eval_index1), length(probs_to_eval_index1),
                                                             length(Label_SlidingWindowX),3))) 
  assign(paste0("array_prob_marg_68_",f), array(NaN,dim=c(length(probs_to_eval_index1), length(probs_to_eval_index1),
                                                          length(Label_SlidingWindowX),3))) 
  assign(paste0("array_prob_dep_68_",f), array(NaN,dim=c(length(probs_to_eval_index1), length(probs_to_eval_index1),
                                                         length(Label_SlidingWindowX),3))) 
} 


#### Compute Copulas. 
print("###################### Init ####################")

Init_index1<-listX_index1[[coord_Ref_SlidingWindow]]
Init_index2<-listX_index2[[coord_Ref_SlidingWindow]]
###What is the quantile associated with probs_to_eval in Ref_SlidingWindow?
quant_Init_index1=Fm1_GPD(Init_index1, quant90_index1, probs_to_eval_index1)
quant_Init_index2=Fm1_GPD(Init_index2, quant90_index2, probs_to_eval_index2)

probs_listX_index1[coord_Ref_SlidingWindow,]=F_GPD(Init_index1, quant90_index1,
                                                   quant_Init_index1)
probs_listX_index2[coord_Ref_SlidingWindow,]=F_GPD(Init_index2, quant90_index2,
                                                   quant_Init_index2)

# ### Compute pseudo-obs. with pobs. more appropriate for the package copula
pobs_Init_index1=pobs(Init_index1)
pobs_Init_index2=pobs(Init_index2)
U_pobs_Init=matrix(NaN,ncol=2,nrow=length(pobs_Init_index1))
U_pobs_Init[,1]=pobs_Init_index1
U_pobs_Init[,2]=pobs_Init_index2

print("###################### Family fixed to Gumbel ####################")
for(f in family_to_try){
  # print(f)
  ### 7.3 Estim. theta at fixed family
  est_cop_f=determine_theta3(U_pobs_Init, f, pobs_to_calc=FALSE)
  ### Save cop_Init for reference period
  assign(paste0("cop_Init_",f), est_cop_f)
  assign(paste0("estim_ci_theta_Init_",f, "_68"),determine_ci_theta2(get(paste0("cop_Init_",f)),
                                                                     U_pobs_Init,
                                                                     ci_level=0.68))
  # print(paste0("Copula Family fixed: ", f, ", ", est_cop_f$family, ", par: ",round(est_cop_f$par,4)))
}

print("###################### Over sliding Window ####################")
time_loop=Sys.time() 
k=0
for(l in Label_SlidingWindowX){
  print(Sys.time()-time_loop) 
  time_loop=Sys.time() 
  print(paste0("##################################### ", l, " #################################"))
  k=k+1
  ### Methodology
  tmp_listX_index1<-listX_index1[[l]]
  tmp_listX_index2<-listX_index2[[l]]
  #### to which proba the quantile associated with probs p
  # in Ref_SlidingWindow correspond to in Sliding_Window?
  probs_listX_index1[k,]=F_GPD(tmp_listX_index1, quant90_index1, quant_Init_index1)
  probs_listX_index2[k,]=F_GPD(tmp_listX_index2, quant90_index2, quant_Init_index2)

  pobs_listX_index1=pobs(tmp_listX_index1)
  pobs_listX_index2=pobs(tmp_listX_index2)
  U_pobs=matrix(NaN,ncol=2,nrow=length(pobs_listX_index1))
  U_pobs[,1]=pobs_listX_index1
  U_pobs[,2]=pobs_listX_index2
 
  #### Do the process for each family
  for(f in family_to_try){
    print(paste0("######### ",f, " ########"))
    if(f=="Clayton"){f_number=3}
    if(f=="Gumbel"){f_number=4}
    if(f=="Frank"){f_number=5}
    if(f=="Joe"){f_number=6}
    ### Estim. theta at fixed family
    est_cop_f=determine_theta3(U_pobs, f, pobs_to_calc=FALSE)
    tmp_cop_f=est_cop_f
    ## Estimate CI of theta_hat 
    estim_ci_theta_f_68=determine_ci_theta2(tmp_cop_f, U_pobs, ci_level=0.68)
    eval(parse(text=paste0("res_theta_",f,"_68[['", l, "']] <- estim_ci_theta_f_68")))
    ##Proba. Margdep: marginal and dependence
    tmp_prob_margdep_68<-determine_ci_prob_bivar_array2(tmp_cop_f,
                                                        estim_ci_theta_f_68,
                                                        probs_listX_index1[k,],
                                                        probs_listX_index2[k,],
                                                        zone_bivar=zone_)
    eval(parse(text=paste0("array_prob_margdep_68_", f,"[,,k,]<-
                          tmp_prob_margdep_68")))
    ##Proba. Marg: marginal only
    tmp_prob_marg_68<-determine_ci_prob_bivar_array2(get(paste0("cop_Init_",f)),
                                                     get(paste0("estim_ci_theta_Init_",f,"_68")),
                                                     probs_listX_index1[k,],
                                                     probs_listX_index2[k,],
                                                     zone_bivar=zone_)
    eval(parse(text=paste0("array_prob_marg_68_", f,"[,,k,]<-
                          tmp_prob_marg_68")))
    ##Proba. Dep: dependence only
    tmp_prob_dep_68<-determine_ci_prob_bivar_array2(tmp_cop_f, estim_ci_theta_f_68, 
                                                    probs_to_eval_index1,
                                                    probs_to_eval_index2,
                                                    zone_bivar=zone_)
    eval(parse(text=paste0("array_prob_dep_68_", f,"[,,k,]<-
                          tmp_prob_dep_68")))
  }
}
### Some warnings can appear 
### all the important warnings have been treated


#### Bootstrap. Please refer to appendix A for more details

boot_param_GPD<-function(data_x, thresh_GPD, points_to_estimate, B, level_){
  ### Fit F_hat with data_x
  test_fit=tryCatch({
    (fitted<- evd::fpot(data_x, thresh_GPD))
  }, error=function(e){})
  if(is.null(test_fit)){
    (fitted <- evd::fpot(data_x, thresh_GPD, std.err=FALSE))
  }else{
    fitted=test_fit
  }
  
  prof_68=confint(fitted, level=level_)
  min_scale=prof_68[1] 
  max_scale=prof_68[3] 
  min_shape=prof_68[2] 
  max_shape=prof_68[4] 
  res_boot_p_of_x=matrix(NaN, nrow=length(points_to_estimate), ncol=B) 
  ### Estimate F_hat(points_to_estimate)
  for(b in 1:B){
    b_scale=runif(1, min_scale, max_scale)
    b_shape=runif(1, min_shape, max_shape)
    res_boot_p_of_x[,b]=evd::pgpd(points_to_estimate,loc =thresh_GPD,
                                  scale=b_scale, shape=b_shape)
  }
  return(res_boot_p_of_x)
}

coord_sub_ts=c(coord_Ref_SlidingWindow:length(Label_SlidingWindowX))
k=0
### For Bootstrap
B=100
b_probs_68_listX_index1=b_probs_68_listX_index2=array(NaN,
                                                      dim=c(length(Label_SlidingWindowX),length(probs_to_eval_index1),B))

for(v in c("margdep", "marg", "dep")){
  for(ci in c(68,95)){
    for(f in c("Gumbel")){
      assign(paste0("tmp_prob_", v, "_v2bis_", ci),  array(NaN,dim=c(length(probs_to_eval_index1),length(probs_to_eval_index2),
                                                                     length(Label_SlidingWindowX),3)))
    }
  }
}
tmp_listX_index1<-listX_index1[[coord_Ref_SlidingWindow]]
tmp_listX_index2<-listX_index2[[coord_Ref_SlidingWindow]]

b_probs_68_listX_index1[coord_Ref_SlidingWindow,,]=boot_param_GPD(tmp_listX_index1, quant90_index1,
                                                                  quant_Init_index1,B, level_=0.68)
b_probs_68_listX_index2[coord_Ref_SlidingWindow,,]=boot_param_GPD(tmp_listX_index2, quant90_index2,
                                                                  quant_Init_index2, B, level_=0.68)



for(l in Label_SlidingWindowX){
  print(Sys.time()-time_loop) 
  time_loop=Sys.time() 
  print(paste0("##################################### ", l, " #################################"))

  k=k+1
  ### Methodology
  tmp_listX_index1<-listX_index1[[l]]
  tmp_listX_index2<-listX_index2[[l]]
  
  #### Re-do the whole methodology for Gumbel family
  for(f in c("Gumbel")){
    print(paste0("######### Bootstrap ",f, " ########"))
    if(f=="Clayton"){f_number=3}
    if(f=="Gumbel"){f_number=4}
    if(f=="Frank"){f_number=5}
    if(f=="Joe"){f_number=6}
    
    b_prob_margdep_68<-array(NaN,dim=c(length(probs_to_eval_index1),length(probs_to_eval_index2),3,B))
    b_prob_marg_68<-array(NaN,dim=c(length(probs_to_eval_index1),length(probs_to_eval_index2),3,B))
    b_prob_dep_68<-array(NaN,dim=c(length(probs_to_eval_index1),length(probs_to_eval_index2),3,B))
    
    if(k!=coord_Ref_SlidingWindow){
      b_probs_68_listX_index1[k,,]=boot_param_GPD(tmp_listX_index1, quant90_index1,
                                                  quant_Init_index1,B, level_=0.68)
      b_probs_68_listX_index2[k,,]=boot_param_GPD(tmp_listX_index2, quant90_index2,
                                                  quant_Init_index2, B, level_=0.68)
    }
    
    tmp_cop_f=list(family=f)
    tmp_theta_Init_f_68=get(paste0("res_theta_", f, "_68"))[[coord_Ref_SlidingWindow]]
    tmp_theta_l_f_68=get(paste0("res_theta_", f, "_68"))[[l]]
    for(b in 1:B){
      # print(b)
      b_prob_margdep_68[,,1,b]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                               tmp_theta_l_f_68[1],
                                                               b_probs_68_listX_index1[k,,b],
                                                               b_probs_68_listX_index2[k,,b],
                                                               zone_bivar=zone_)
      b_prob_marg_68[,,1,b]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                            tmp_theta_Init_f_68[1],
                                                            b_probs_68_listX_index1[k,,b],
                                                            b_probs_68_listX_index2[k,,b],
                                                            zone_bivar=zone_)
      b_prob_dep_68[,,1,b]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                           tmp_theta_l_f_68[1],
                                                           b_probs_68_listX_index1[coord_Ref_SlidingWindow,,b],
                                                           b_probs_68_listX_index2[coord_Ref_SlidingWindow,,b],
                                                           zone_bivar=zone_)
    }
    
    ### For ci 68
    #for each proba, Which bootstrap is responsible of the 84% percentile? 16% percentile?
    if(zone_=="topright"){
      coord_b_sup_margdep_68=apply(b_prob_margdep_68[,,1,],c(1,2),
                                   function(x){return(which(x==sort(x)[trunc(B*0.84)])[1])})
      coord_b_inf_margdep_68=apply(b_prob_margdep_68[,,1,],c(1,2),
                                   function(x){return(which(x==sort(x)[trunc(B*0.16)])[1])})
      coord_b_sup_marg_68=apply(b_prob_marg_68[,,1,],c(1,2),
                                function(x){return(which(x==sort(x)[trunc(B*0.84)])[1])})
      coord_b_inf_marg_68=apply(b_prob_marg_68[,,1,],c(1,2),
                                function(x){return(which(x==sort(x)[trunc(B*0.16)])[1])})
      coord_b_sup_dep_68=apply(b_prob_dep_68[,,1,],c(1,2),
                               function(x){return(which(x==sort(x)[trunc(B*0.84)])[1])})
      coord_b_inf_dep_68=apply(b_prob_dep_68[,,1,],c(1,2),
                               function(x){return(which(x==sort(x)[trunc(B*0.16)])[1])})
    }
    
    for(p_i2 in 1:length(probs_to_eval_index2)){
      for(p_i1 in 1:length(probs_to_eval_index1)){
        tmp_prob_margdep_v2bis_68[p_i2,p_i1,k,3]<-determine_bootstrap_prob_bivar(tmp_cop_f, tmp_theta_l_f_68[3],
                                                                                 prob_vector1=b_probs_68_listX_index1[k,p_i1,unlist(coord_b_sup_margdep_68[p_i2,p_i1])],
                                                                                 prob_vector2=b_probs_68_listX_index2[k,p_i2,
                                                                                                                      unlist(coord_b_sup_margdep_68[p_i2,p_i1])],
                                                                                 zone_bivar=zone_)
        tmp_prob_margdep_v2bis_68[p_i2,p_i1,k,2]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                                 tmp_theta_l_f_68[2],
                                                                                 prob_vector1=b_probs_68_listX_index1[k,p_i1,unlist(coord_b_inf_margdep_68[p_i2,p_i1])],
                                                                                 prob_vector2=b_probs_68_listX_index2[k,p_i2,
                                                                                                                      unlist(coord_b_inf_margdep_68[p_i2,p_i1])],
                                                                                 zone_bivar=zone_)
        tmp_prob_margdep_v2bis_68[p_i2,p_i1,k,1]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                                 tmp_theta_l_f_68[1],
                                                                                 prob_vector1=probs_listX_index1[k,p_i1],
                                                                                 prob_vector2=probs_listX_index2[k,p_i2],
                                                                                 zone_bivar=zone_)
      }
    }
    for(p_i2 in 1:length(probs_to_eval_index2)){
      for(p_i1 in 1:length(probs_to_eval_index1)){
        tmp_prob_marg_v2bis_68[p_i2,p_i1,k,3]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                              tmp_theta_Init_f_68[3],
                                                                              prob_vector1=b_probs_68_listX_index1[k,p_i1,unlist(coord_b_sup_marg_68[p_i2,p_i1])],
                                                                              prob_vector2=b_probs_68_listX_index2[k,p_i2,
                                                                                                                   unlist(coord_b_sup_marg_68[p_i2,p_i1])],
                                                                              zone_bivar=zone_)
        tmp_prob_marg_v2bis_68[p_i2,p_i1,k,2]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                              tmp_theta_Init_f_68[2],
                                                                              prob_vector1=b_probs_68_listX_index1[k,p_i1,unlist(coord_b_inf_marg_68[p_i2,p_i1])],
                                                                              prob_vector2=b_probs_68_listX_index2[k,p_i2,
                                                                                                                   unlist(coord_b_inf_marg_68[p_i2,p_i1])],
                                                                              zone_bivar=zone_)
        tmp_prob_marg_v2bis_68[p_i2,p_i1,k,1]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                              tmp_theta_Init_f_68[1],
                                                                              prob_vector1=probs_listX_index1[k,p_i1],
                                                                              prob_vector2=probs_listX_index2[k,p_i2],
                                                                              zone_bivar=zone_)
      }
    }
    for(p_i2 in 1:length(probs_to_eval_index2)){
      for(p_i1 in 1:length(probs_to_eval_index1)){
        tmp_prob_dep_v2bis_68[p_i2,p_i1,k,3]<-determine_bootstrap_prob_bivar(tmp_cop_f, tmp_theta_l_f_68[3],
                                                                             prob_vector1=b_probs_68_listX_index1[coord_Ref_SlidingWindow,p_i1,unlist(coord_b_sup_dep_68[p_i2,p_i1])],
                                                                             prob_vector2=b_probs_68_listX_index2[coord_Ref_SlidingWindow,p_i2,
                                                                                                                  unlist(coord_b_sup_dep_68[p_i2,p_i1])],
                                                                             zone_bivar=zone_)
        tmp_prob_dep_v2bis_68[p_i2,p_i1,k,2]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                             tmp_theta_l_f_68[2],
                                                                             prob_vector1=b_probs_68_listX_index1[coord_Ref_SlidingWindow,p_i1,unlist(coord_b_inf_dep_68[p_i2,p_i1])],
                                                                             prob_vector2=b_probs_68_listX_index2[coord_Ref_SlidingWindow,p_i2,
                                                                                                                  unlist(coord_b_inf_dep_68[p_i2,p_i1])],
                                                                             zone_bivar=zone_)
        tmp_prob_dep_v2bis_68[p_i2,p_i1,k,1]<-determine_bootstrap_prob_bivar(tmp_cop_f,
                                                                             tmp_theta_l_f_68[1],
                                                                             prob_vector1=probs_listX_index1[coord_Ref_SlidingWindow,p_i1],
                                                                             prob_vector2=probs_listX_index2[coord_Ref_SlidingWindow,p_i2],
                                                                             zone_bivar=zone_)
      }
    }
  }
}

### Store the results
for(f in c("Gumbel")){
  for(v in c("margdep", "marg", "dep")){
    for(ci in c("68")){#}, "95")){#, "95")){
      eval(parse(text=(paste0("array_prob_",v,"_v2bis_",ci,"_", f,"<-tmp_prob_", v,
                              "_v2bis_", ci))))
    }
  }
}


### Quick plots
### Plot the probability time series of the CE for:
### index2 above the 1th value in probs_to_eval, i.e. the 80th percentiles
### index1 above the 1th value in probs_to_eval, i.e. the 80th percentiles
### for the sliding windows going from 1871-1900 (the 22nd)
### to the 2071-2100 (the 222nd)
### for estimated proba (1), CI low (2) and CI high (3)
plot(array_prob_dep_68_Gumbel[1,1,22:222,1],type='l',ylim=c(0,0.2))
lines(array_prob_dep_68_Gumbel[1,1,22:222,2],type='l',col='orange')
lines(array_prob_dep_68_Gumbel[1,1,22:222,3],type='l',col='orange')
### with CI estimated by bootstrap 
lines(array_prob_dep_v2bis_68_Gumbel[1,1,22:222,2],type='l',col='red')
lines(array_prob_dep_v2bis_68_Gumbel[1,1,22:222,3],type='l',col='red')
abline(h=array_prob_dep_v2bis_68_Gumbel[1,1,22,2],col='red')
abline(h=array_prob_dep_v2bis_68_Gumbel[1,1,22,3],col='red')
abline(h=array_prob_dep_68_Gumbel[1,1,22,2],col='orange')
abline(h=array_prob_dep_68_Gumbel[1,1,22,3],col='orange')

### Save the results
setwd("/home/francois/Documents/LSCE/TCE6/Demo/")
save(list=c("array_prob_dep_68_Gumbel", 
            "array_prob_margdep_68_Gumbel", 
            "array_prob_marg_68_Gumbel",
            "array_prob_dep_v2bis_68_Gumbel", 
            "array_prob_margdep_v2bis_68_Gumbel", 
            "array_prob_marg_v2bis_68_Gumbel"), 
     file="save_data_demo_CNRMCM6_Gumbel.RData")





############################################################################
############################################################################
### Reproduction of some of the figures of the article
rm(list=ls())
setwd("/home/francois/Documents/LSCE/TCE6/Demo/")
source("function_Demo_ToE.R")

load("save_data_demo_CNRMCM6_Gumbel.RData")

pdf("CNRMCM6_ToE_Wind_and_Pr.pdf", width=12, height=4)
par(mfrow=c(1,3))
###Marg-dep 
plot(array_prob_margdep_68_Gumbel[1,1,22:222,1]~c(1886:2086),ylab="Proba.", xlab="Years", type='l',ylim=c(0,0.2), main="Marg-dep")
lines(array_prob_margdep_v2bis_68_Gumbel[1,1,22:222,2]~c(1886:2086),type='l',col='red')
lines(array_prob_margdep_v2bis_68_Gumbel[1,1,22:222,3]~c(1886:2086),type='l',col='red')
abline(h=array_prob_margdep_v2bis_68_Gumbel[1,1,22,2],col='red')
abline(h=array_prob_margdep_v2bis_68_Gumbel[1,1,22,3],col='red')
### Compute ToE
Toe_res=compute_ToE_matrix_from_array(array_prob_margdep_v2bis_68_Gumbel, length_SlidingWindow=30,
                                      period_="1871_2100", coord_baseline=22)
abline(v=Toe_res$TOE[1,1],col='red')
##Marg
plot(array_prob_marg_68_Gumbel[1,1,22:222,1]~c(1886:2086),ylab="Proba.", xlab="Years", type='l',ylim=c(0,0.2), main="Marg")
lines(array_prob_marg_v2bis_68_Gumbel[1,1,22:222,2]~c(1886:2086),type='l',col='red')
lines(array_prob_marg_v2bis_68_Gumbel[1,1,22:222,3]~c(1886:2086),type='l',col='red')
abline(h=array_prob_marg_v2bis_68_Gumbel[1,1,22,2],col='red')
abline(h=array_prob_marg_v2bis_68_Gumbel[1,1,22,3],col='red')
### Compute ToE
Toe_res=compute_ToE_matrix_from_array(array_prob_marg_v2bis_68_Gumbel, length_SlidingWindow=30,
                                      period_="1871_2100", coord_baseline=22)
abline(v=Toe_res$TOE[1,1],col='red')
##Dep 
plot(array_prob_dep_68_Gumbel[1,1,22:222,1]~c(1886:2086),ylab="Proba.", xlab="Years", type='l',ylim=c(0,0.2), main="Dep")
lines(array_prob_dep_v2bis_68_Gumbel[1,1,22:222,2]~c(1886:2086),type='l',col='red')
lines(array_prob_dep_v2bis_68_Gumbel[1,1,22:222,3]~c(1886:2086),type='l',col='red')
abline(h=array_prob_dep_v2bis_68_Gumbel[1,1,22,2],col='red')
abline(h=array_prob_dep_v2bis_68_Gumbel[1,1,22,3],col='red')
### Compute ToE
Toe_res=compute_ToE_matrix_from_array(array_prob_dep_v2bis_68_Gumbel, length_SlidingWindow=30,
                                        period_="1871_2100", coord_baseline=22)
abline(v=Toe_res$TOE[1,1],col='red')
dev.off()



### Compute Contribution marg and dep
Contrib_res=compute_Contrib_matrix_from_array(array_prob_margdep_v2bis_68_Gumbel, 
                                              array_prob_marg_v2bis_68_Gumbel, 
                                              array_prob_dep_v2bis_68_Gumbel, 22)
## To plot Contribution time series
xlab_name=seq.int(1886,2086,20)
xlab_pos=seq(1,201,20)
col_main=c("dodgerblue","darkorange", "gray", "indianred1") # "chartreuse3"

pdf("CNRMCM6_Contrib_Wind_and_Pr.pdf", width=12, height=4)
par(mfrow=c(1,3))
fastplot_Contrib(Contrib_res,p_i2=1,p_i1=1, plot_ts=TRUE, plot_matrix=FALSE,
                 plot_barplot=FALSE,coord_sub_ts=22:222,
                           subplot_name=c("(d)", "(e)", "(f)"))
dev.off()